import { Module } from '@nestjs/common';
import { AppController } from './app.controller';
import { AppService } from './app.service';
import { TypeOrmModule } from '@nestjs/typeorm';
import { QtyTypeModule } from './inventory-management/qty-type/qty-type.module';
import { SupplierModule } from './item-management/supplier/supplier.module';
import { ProductsModule } from './item-management/products/products.module';
import { QtyModule } from './inventory-management/qty/qty.module';
import { ItemSellModule } from './sale-management/item-sell/item-sell.module';
import { InvoiceModule } from './sale-management/invoice/invoice.module';
import { CustomerModule } from './sale-management/customer/customer.module';
import { ProductPriceModule } from './item-management/product-prices/product-prices.module';
import { ConfigModule, ConfigService } from '@nestjs/config';
@Module({
  imports: [
    // TypeOrmModule.forRootAsync({
    //   imports: [ConfigModule],
    //   inject: [ConfigService],
    //   useFactory: (configService: ConfigService) => ({
    //     type: 'mysql',
    //     host: configService.get('DB_HOST', '127.0.0.1'),
    //     port: +configService.get('DB_PORT', 3306),
    //     username: configService.get('DB_USERNAME', 'nimbwsmp_kesara'),
    //     password: configService.get('DB_PASSWORD', 'Payroll@1234'),
    //     database: configService.get('DB_DATABASE','nimbwsmp_pos'),
    //     entities: [__dirname + '/**/*.entity{.ts,.js}'],
    //     synchronize: configService.get('DB_SYNCHRONIZE', true),
    //   }),
    // }),

    TypeOrmModule.forRoot({
      type: 'mysql', // Database type
      host: 'localhost', // MySQL server host
      port: 3306, // MySQL server port
      username: 'root', // MySQL username
      password: '', // MySQL password
      database: 'pos', // Database name
      entities: [__dirname + '/**/*.entity{.ts,.js}'], // Entity files
      synchronize: true, // Automatically sync database schema (not recommended for production)
      logging: true, // Enable logging for debugging
    }),


    // TypeOrmModule.forRoot({
    //   type: 'sqlite', // Switch to SQLite
    //   database: ':memory:', // In-memory database
    //   entities: [__dirname + '/**/*.entity{.ts,.js}'], // Same entity files
    //   synchronize: true, // Auto-create tables (safe for in-memory)
    //   logging: true, // Enable logging for debugging
    // }),
    SupplierModule,
    ProductsModule,
    ProductPriceModule,
    QtyModule,
    ItemSellModule,
    InvoiceModule,
    CustomerModule,
    QtyTypeModule

  ],
  
  controllers: [AppController],
  providers: [AppService,],
  
})
export class AppModule {}
