import { Injectable, NotFoundException } from "@nestjs/common";
import { InjectRepository } from "@nestjs/typeorm";
import { async } from "rxjs";
import { Product } from "src/item-management/products/entities/product.entity";
import { Repository } from "typeorm";
import { ItemSell } from "../item-sell/entities/item-sell.entity";
import { CreateInvoiceDto } from "./dto/create-invoice.dto";
import { UpdateInvoiceDto } from "./dto/update-invoice.dto";
import { Invoice } from "./entities/invoice.entity";

@Injectable()
export class InvoiceService {
  constructor(
    @InjectRepository(Invoice)
    private invoiceRepository: Repository<Invoice>,
    @InjectRepository(ItemSell)
    private itemSellRepository: Repository<ItemSell>,
    @InjectRepository(Product)
    private productRepository: Repository<Product>,
  ) { }

  async create(createInvoiceDto: CreateInvoiceDto): Promise<Invoice> {
    const queryRunner = this.invoiceRepository.manager.connection.createQueryRunner();

    await queryRunner.connect();
    await queryRunner.startTransaction();

    try {
      // Step 1: Create and save invoice
      const { itemsSelled: itemsSelledDtos, ...invoiceData } = createInvoiceDto;

      const invoice = this.invoiceRepository.create(invoiceData);
      const savedInvoice = await queryRunner.manager.save(invoice);

      let total = 0;

      // Step 2: Process each item in itemsSelled
      for (const itemDto of itemsSelledDtos) {
        const product = await this.productRepository.findOne({
          where: { id: itemDto.productId },
        });

        if (!product) {
          throw new NotFoundException(`Product with ID ${itemDto.productId} not found`);
        }

        if (product.qty < itemDto.qty) {
          throw new Error(`Insufficient stock for product ${product.name}`);
        }

        // Deduct quantity
        product.qty -= itemDto.qty;
        await queryRunner.manager.save(product);

        // Create ItemSell and associate with the SAVED invoice
        const itemSell = this.itemSellRepository.create();
        itemSell.qty = itemDto.qty;
        itemSell.qntPrice = itemDto.qty * product.currentPrice;
        itemSell.product = product;
        itemSell.invoice = savedInvoice;
        itemSell.qtyType = itemDto.product?.qtyType || product.qtyType;
        itemSell.pendingdAmount = itemDto.pendingdAmount;
        itemSell.completedItemSell = itemDto.completedItemSell;

        await queryRunner.manager.save(itemSell);

        total += itemSell.qntPrice;
      }

      // Step 3: Update invoice total
      savedInvoice.total = total;
      savedInvoice.netTotal = total - savedInvoice.discount;
      await queryRunner.manager.save(savedInvoice);

      // Commit transaction
      await queryRunner.commitTransaction();

      // Step 4: Return the updated invoice with relations
      return await this.invoiceRepository.findOne({
        where: { id: savedInvoice.id },
        relations: {
          itemsSelled: {
            product: true,
            qtyType: true,
          },
        },
      });
    } catch (error) {
      await queryRunner.rollbackTransaction();
      throw error;
    } finally {
      await queryRunner.release();
    }
  }

  async findAll(): Promise<Invoice[]> {
    return await this.invoiceRepository.find({
      relations: {
        itemsSelled: {
          product: true,
          qtyType: true,
        },
      },
    });
  }

  async findOne(id: number): Promise<Invoice> {
    const invoice = await this.invoiceRepository.findOne({
      where: { id },
      relations: ['itemsSelled', 'itemsSelled.product'],
    });
    if (!invoice) {
      throw new NotFoundException(`Invoice with ID ${id} not found`);
    }
    return invoice;
  }

  async update(id: number, updateInvoiceDto: UpdateInvoiceDto): Promise<Invoice> {
    const invoice = await this.invoiceRepository.findOne({ where: { id } });
    if (!invoice) {
      throw new NotFoundException(`Invoice with ID ${id} not found`);
    }

    await this.invoiceRepository.update(id, updateInvoiceDto);
    return await this.invoiceRepository.findOne({ where: { id } });
  }

  async remove(id: number): Promise<void> {
    const invoice = await this.invoiceRepository.findOne({ where: { id } });
    if (!invoice) {
      throw new NotFoundException(`Invoice with ID ${id} not found`);
    }

    await this.invoiceRepository.remove(invoice);
  }
}
