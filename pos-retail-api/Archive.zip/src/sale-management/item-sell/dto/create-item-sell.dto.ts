import { CreateQtyDto } from "src/inventory-management/qty/dto/create-qty.dto";
import { Product } from "src/item-management/products/entities/product.entity";

export class CreateItemSellDto {

  productId: number;
  product?:Product;
  qtyTypeId: number;
  qtyType?:CreateQtyDto;
  qty: number;
  qntPrice: number;
  status?: number;
  pendingdAmount?: number;
  completedItemSell?: boolean;
}